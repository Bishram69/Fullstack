USE course_management;

-- Add 'instructor' to users.role
ALTER TABLE users MODIFY COLUMN role ENUM('admin', 'student', 'instructor') NOT NULL DEFAULT 'student';

-- Add instructor_id to courses 
ALTER TABLE courses ADD COLUMN instructor_id INT NULL AFTER price;
ALTER TABLE courses ADD CONSTRAINT fk_courses_instructor FOREIGN KEY (instructor_id) REFERENCES users(id) ON DELETE SET NULL;

(function () {
    'use strict';

    var searchInput = document.getElementById('search-input');
    var searchResults = document.getElementById('search-results');
    var courseList = document.getElementById('course-list');

    if (!searchInput || !searchResults || !courseList) {
        return;
    }

    var debounceTimer;
    searchInput.addEventListener('input', function () {
        var query = searchInput.value.trim();

        clearTimeout(debounceTimer);

        if (query.length === 0) {
            searchResults.innerHTML = '';
            searchResults.classList.remove('visible');
            courseList.style.display = 'block';
            return;
        }

        debounceTimer = setTimeout(function () {
            fetchSearch(query);
        }, 300);
    });

    /**
     * @param {string} query - Search term
     */
    function fetchSearch(query) {
        var url = 'search.php?q=' + encodeURIComponent(query);

        fetch(url)
            .then(function (response) {
                if (!response.ok) {
                    throw new Error('Search failed');
                }
                return response.json();
            })
            .then(function (courses) {
                displayResults(courses);
            })
            .catch(function () {
                searchResults.innerHTML = '<p class="search-error">Search unavailable.</p>';
                searchResults.classList.add('visible');
            });
    }

    function formatDate(dateStr) {
        if (!dateStr) return '—';
        var part = String(dateStr).split(' ')[0];
        return part || '—';
    }

    /**
     * @param {Array} courses - Array of course objects from server
     */
    function displayResults(courses) {
        courseList.style.display = courses.length ? 'none' : 'block';

        if (courses.length === 0) {
            searchResults.innerHTML = '<p class="search-empty">No courses found.</p>';
        } else {
            var isAdmin = typeof window.IS_ADMIN !== 'undefined' && window.IS_ADMIN;
            var html = '<table class="course-table search-results-table">';
            html += '<thead><tr>';
            html += '<th>Title</th><th>Category</th><th>Instructor</th>';
            html += '<th class="col-price">Price</th><th class="col-created">Created</th>';
            html += isAdmin ? '<th>Actions</th>' : '<th>Enroll</th>';
            html += '</tr></thead><tbody>';
            courses.forEach(function (course) {
                var instructor = (course.instructor_username && course.instructor_username.length) ? escapeHtml(course.instructor_username) : '—';
                var price = 'NPR ' + escapeHtml(String(Number(course.price).toFixed(2)));
                var created = formatDate(course.created_at);
                html += '<tr>';
                html += '<td>' + escapeHtml(course.title) + '</td>';
                html += '<td>' + escapeHtml(course.category) + '</td>';
                html += '<td>' + instructor + '</td>';
                html += '<td class="col-price">' + price + '</td>';
                html += '<td class="col-created">' + created + '</td>';
                if (isAdmin) {
                    html += '<td class="actions">';
                    html += '<a href="edit_course.php?id=' + escapeHtml(String(course.id)) + '" class="btn btn-small">Edit</a> ';
                    html += '<a href="delete_course.php?id=' + escapeHtml(String(course.id)) + '" class="btn btn-small btn-danger" onclick="return confirm(\'Delete this course?\');">Delete</a>';
                    html += '</td>';
                } else {
                    html += '<td class="enroll-cell">';
                    if (course.enrolled) {
                        html += '<span class="badge-enrolled">Enrolled</span>';
                    } else {
                        html += '<a href="enroll.php?course_id=' + escapeHtml(String(course.id)) + '" class="btn btn-small btn-primary">Enroll</a>';
                    }
                    html += '</td>';
                }
                html += '</tr>';
            });
            html += '</tbody></table>';
            searchResults.innerHTML = html;
        }

        searchResults.classList.add('visible');
    }

    /**
     * @param {string} text
     * @returns {string}
     */
    function escapeHtml(text) {
        var div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
})();

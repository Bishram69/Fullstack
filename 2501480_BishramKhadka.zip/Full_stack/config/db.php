<?php
if (!defined('DB_CONFIG_LOADED')) {
    define('DB_CONFIG_LOADED', true);
}


$db_host = 'localhost';
$db_name = 'np03cs4a240036';
$db_user = 'np03cs4a240036';
$db_pass = 'jKX72aMMIS';  


$dsn = "mysql:host=$db_host;dbname=$db_name;charset=utf8mb4";


$options = [
    
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
   
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    
    $pdo = new PDO($dsn, $db_user, $db_pass, $options);
} catch (PDOException $e) {
    
    die('Database connection failed. Please check config/db.php and try again.');
}

<?php
require_once __DIR__ . '/db.php';

$new_password = 'admin123';
$hashed = password_hash($new_password, PASSWORD_DEFAULT);

$stmt = $pdo->prepare('UPDATE users SET password = ? WHERE username = ?');
$stmt->execute([$hashed, 'admin']);

if ($stmt->rowCount() > 0) {
    echo 'Admin password updated to: admin123. You can now log in.';
} else {
    echo 'No admin user found. Run database.sql first.';
}

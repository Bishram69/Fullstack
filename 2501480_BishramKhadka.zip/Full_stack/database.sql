-- Create the database 
CREATE DATABASE IF NOT EXISTS course_management;
USE course_management;
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL COMMENT 'Stored as bcrypt hash',
    role ENUM('admin', 'student', 'instructor') NOT NULL DEFAULT 'student',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE IF NOT EXISTS courses (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    category VARCHAR(100) NOT NULL,
    price DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    instructor_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (instructor_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS enrollments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    course_id INT NOT NULL,
    enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_enrollment (user_id, course_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT INTO users (username, password, role) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');


INSERT INTO users (username, password, role) VALUES
('student', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student');


INSERT INTO users (username, password, role) VALUES
('instructor1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'instructor');


INSERT INTO courses (title, description, category, price, instructor_id) VALUES
('Introduction to PHP', 'Learn PHP basics: variables, loops, functions, and forms. Perfect for beginners.', 'Programming', 49.99, 3),
('MySQL Database Fundamentals', 'Understand databases, SQL queries, and table design. Includes PDO in PHP.', 'Database', 59.99, 3),
('Web Security Basics', 'Prevent SQL injection, XSS, and CSRF. Learn secure coding practices.', 'Security', 69.99, NULL),
('HTML & CSS for Beginners', 'Build responsive websites with semantic HTML and modern CSS.', 'Web Design', 39.99, NULL),
('JavaScript Essentials', 'Variables, DOM manipulation, Ajax, and ES6 features.', 'Programming', 54.99, NULL);


INSERT INTO enrollments (user_id, course_id) VALUES (2, 1), (2, 3);



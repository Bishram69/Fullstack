    </main>
    <footer class="site-footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> Course Management System (CMS)</p>
        </div>
    </footer>
</body>
</html>

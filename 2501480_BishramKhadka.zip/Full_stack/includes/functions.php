<?php


// Start session only if not already started 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in.
function require_login() {
    if (empty($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
}


 // Check if current user is admin.
function is_admin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

//Require admin role. Redirects to dashboard if not admin
function require_admin() {
    if (!is_admin()) {
        header('Location: dashboard.php?error=access_denied');
        exit;
    }
}

/**
 * Generate a CSRF token and store it in the session.
 * Call this when displaying a form that uses POST.
 *
 * @return string The token value to put in a hidden form field
 */
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        // Generate random token (32 bytes = 64 hex characters)
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Validate that the submitted form has the correct CSRF token.

function csrf_valid() {
    if (empty($_POST['csrf_token']) || empty($_SESSION['csrf_token'])) {
        return false;
    }
   
    return hash_equals($_SESSION['csrf_token'], $_POST['csrf_token']);
}

function e($string) {
    return htmlspecialchars((string) $string, ENT_QUOTES, 'UTF-8');
}

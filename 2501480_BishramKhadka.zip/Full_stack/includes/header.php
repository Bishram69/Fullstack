<?php
if (!isset($page_title)) {
    $page_title = 'Course Management System';
}

$base = dirname(dirname($_SERVER['SCRIPT_NAME'] ?? ''));
if (basename($base) === 'public') {
    $base = dirname($base);
}
$base = rtrim(str_replace('\\', '/', $base), '/');
$css_href = ($base !== '' ? $base . '/' : '') . 'assets/css/style.css';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($page_title); ?> | CMS</title>
    <link rel="stylesheet" href="<?php echo e($css_href); ?>">
</head>
<body class="cms-theme">
    <header class="site-header cms-header">
        <div class="container">
            <h1 class="logo">
                <a href="dashboard.php">Course Management System</a>
                <span class="logo-tagline">CMS</span>
            </h1>
            <nav class="main-nav">
                <?php if (!empty($_SESSION['user_id'])): ?>
                    <!-- User is logged in - show dashboard and logout -->
                    <a href="dashboard.php">Dashboard</a>
                    <?php if (function_exists('is_admin') && is_admin()): ?>
                    <a href="add_course.php">Add Course</a>
                    <a href="add_instructor.php">Add Instructor</a>
                    <?php else: ?>
                    <a href="my_courses.php">My Courses</a>
                    <?php endif; ?>
                    <span class="user-info"><?php echo e($_SESSION['username'] ?? ''); ?> (<?php echo e($_SESSION['role'] ?? ''); ?>)</span>
                    <a href="logout.php" class="btn-logout">Logout</a>
                <?php else: ?>
                    <!-- User not logged in - show login and register -->
                    <a href="login.php">Login</a>
                    <a href="register.php">Register</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>
    <main class="main-content">

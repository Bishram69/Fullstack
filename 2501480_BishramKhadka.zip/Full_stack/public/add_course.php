<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

require_login();
require_admin();

$page_title = 'Add Course';
$errors = [];
$success = false;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // CSRF check - reject if token missing or invalid
    if (!csrf_valid()) {
        $errors[] = 'Invalid request. Please try again.';
    } else {
        // Get and trim inputs
        $title       = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $category    = trim($_POST['category'] ?? '');
        $price       = trim($_POST['price'] ?? '0');

        // Server-side validation
        if (empty($title)) {
            $errors[] = 'Title is required.';
        }
        if (strlen($title) > 200) {
            $errors[] = 'Title must be 200 characters or less.';
        }
        if (empty($category)) {
            $errors[] = 'Category is required.';
        }
        if (strlen($category) > 100) {
            $errors[] = 'Category must be 100 characters or less.';
        }
        if (!is_numeric($price) || $price < 0) {
            $errors[] = 'Price must be a non-negative number.';
        }

        if (empty($errors)) {
            $instructor_id = isset($_POST['instructor_id']) && $_POST['instructor_id'] !== '' ? (int) $_POST['instructor_id'] : null;
            if ($instructor_id <= 0) {
                $instructor_id = null;
            }
            // Insert using prepared statement (prevents SQL injection)
            $stmt = $pdo->prepare('INSERT INTO courses (title, description, category, price, instructor_id) VALUES (?, ?, ?, ?, ?)');
            $stmt->execute([$title, $description, $category, (float) $price, $instructor_id]);

            $success = true;
            // Optionally redirect to dashboard: header('Location: dashboard.php'); exit;
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container form-page">
    <h2>Add New Course</h2>

    <?php if ($success): ?>
        <div class="alert alert-success">Course added successfully. <a href="dashboard.php">Back to dashboard</a></div>
    <?php endif; ?>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <ul>
                <?php foreach ($errors as $err): ?>
                    <li><?php echo e($err); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" action="add_course.php" class="form-box">
        <!-- CSRF token - must match session token when form is submitted -->
        <input type="hidden" name="csrf_token" value="<?php echo e(csrf_token()); ?>">

        <div class="form-group">
            <label for="title">Title *</label>
            <input type="text" id="title" name="title" required maxlength="200"
                   value="<?php echo e($_POST['title'] ?? ''); ?>">
        </div>
        <div class="form-group">
            <label for="description">Description</label>
            <textarea id="description" name="description" rows="4"><?php echo e($_POST['description'] ?? ''); ?></textarea>
        </div>
        <div class="form-group">
            <label for="category">Category *</label>
            <input type="text" id="category" name="category" required maxlength="100"
                   value="<?php echo e($_POST['category'] ?? ''); ?>">
        </div>
        <div class="form-group">
            <label for="price">Price (NPR) *</label>
            <input type="number" id="price" name="price" step="0.01" min="0" value="<?php echo e($_POST['price'] ?? '0'); ?>" required>
        </div>
        <div class="form-group">
            <label for="instructor_id">Instructor</label>
            <select id="instructor_id" name="instructor_id">
                <option value="">— No instructor —</option>
                <?php foreach ($instructors as $inst): ?>
                <option value="<?php echo (int) $inst['id']; ?>"<?php echo (isset($_POST['instructor_id']) && (int) $_POST['instructor_id'] === (int) $inst['id']) ? ' selected' : ''; ?>><?php echo e($inst['username']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Add Course</button>
            <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

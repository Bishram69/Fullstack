<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Redirect to login if not logged in
require_login();

$page_title = 'Dashboard - Courses';

// Show success message if redirected after delete
$deleted = isset($_GET['deleted']) && $_GET['deleted'] === '1';
$enrolled_success = isset($_GET['enrolled']) && $_GET['enrolled'] === '1';
$error_enroll = isset($_GET['error']) ? $_GET['error'] : '';

// Fetch all courses with instructor
$stmt = $pdo->query('
    SELECT c.id, c.title, c.description, c.category, c.price, c.created_at, c.instructor_id,
           u.username AS instructor_username
    FROM courses c
    LEFT JOIN users u ON c.instructor_id = u.id
    ORDER BY c.created_at DESC
');
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

// For students: get list of course IDs they are enrolled in
$enrolled_course_ids = [];
if (!is_admin() && !empty($_SESSION['user_id'])) {
    $stmt = $pdo->prepare('SELECT course_id FROM enrollments WHERE user_id = ?');
    $stmt->execute([(int) $_SESSION['user_id']]);
    $enrolled_course_ids = array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'course_id');
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container">
    <div class="page-header">
        <h2>All Courses</h2>
        <?php if (is_admin()): ?>
        <a href="add_course.php" class="btn btn-primary">Add New Course</a>
        <?php endif; ?>
    </div>

    <?php if (isset($_GET['error']) && $_GET['error'] === 'access_denied'): ?>
        <div class="alert alert-warning">You do not have permission to perform that action. Only administrators can add, edit, or delete courses.</div>
    <?php endif; ?>
    <?php if ($deleted): ?>
        <div class="alert alert-success">Course deleted.</div>
    <?php endif; ?>
    <?php if ($enrolled_success): ?>
        <div class="alert alert-success">You have been enrolled in the course.</div>
    <?php endif; ?>
    <?php if ($error_enroll === 'already_enrolled'): ?>
        <div class="alert alert-warning">You are already enrolled in that course.</div>
    <?php endif; ?>
    <?php if ($error_enroll === 'invalid_course'): ?>
        <div class="alert alert-error">Invalid course.</div>
    <?php endif; ?>
    <?php if ($error_enroll === 'admin_cannot_enroll'): ?>
        <div class="alert alert-warning">Only students can enroll in courses.</div>
    <?php endif; ?>

    <!-- Live search box - Ajax updates results without page reload -->
    <div class="search-box">
        <label for="search-input">Search courses (by title or instructor):</label>
        <input type="text" id="search-input" placeholder="Type to search..." autocomplete="off">
        <div id="search-results"></div>
    </div>

    <!-- Full course list (shown when not searching) -->
    <div id="course-list">
        <?php if (empty($courses)): ?>
            <p class="no-data">No courses yet.<?php if (is_admin()): ?> <a href="add_course.php">Add your first course</a>.<?php endif; ?></p>
        <?php else: ?>
            <table class="course-table">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Instructor</th>
                        <th class="col-price">Price</th>
                        <th class="col-created">Created</th>
                        <?php if (is_admin()): ?><th>Actions</th><?php elseif (!is_admin()): ?><th>Enroll</th><?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($courses as $course): ?>
                        <tr>
                            <td><?php echo e($course['title']); ?></td>
                            <td><?php echo e($course['category']); ?></td>
                            <td><?php echo !empty($course['instructor_username']) ? e($course['instructor_username']) : '—'; ?></td>
                            <td class="col-price">NPR <?php echo e(number_format($course['price'], 2)); ?></td>
                            <td class="col-created"><?php echo e(date('Y-m-d', strtotime($course['created_at']))); ?></td>
                            <?php if (is_admin()): ?>
                            <td class="actions">
                                <a href="edit_course.php?id=<?php echo (int) $course['id']; ?>" class="btn btn-small">Edit</a>
                                <a href="delete_course.php?id=<?php echo (int) $course['id']; ?>" class="btn btn-small btn-danger" onclick="return confirm('Delete this course?');">Delete</a>
                            </td>
                            <?php else: ?>
                            <td class="enroll-cell">
                                <?php if (in_array((int) $course['id'], $enrolled_course_ids, true)): ?>
                                    <span class="badge-enrolled">Enrolled</span>
                                <?php else: ?>
                                    <a href="enroll.php?course_id=<?php echo (int) $course['id']; ?>" class="btn btn-small btn-primary">Enroll</a>
                                <?php endif; ?>
                            </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<!-- Expose admin flag for search.js (so students don't see edit links in search results) -->
<script>window.IS_ADMIN = <?php echo is_admin() ? 'true' : 'false'; ?>;</script>
<script src="../assets/js/search.js"></script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

require_login();
require_admin();

// Get course ID from URL
$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($id <= 0) {
    header('Location: dashboard.php');
    exit;
}

// Optional: require confirmation via POST to avoid accidental delete from link
$confirmed = ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['confirm']));

if ($confirmed) {
    $stmt = $pdo->prepare('DELETE FROM courses WHERE id = ?');
    $stmt->execute([$id]);
    // Redirect to dashboard after delete
    header('Location: dashboard.php?deleted=1');
    exit;
}

// If GET request, show confirmation page
$stmt = $pdo->prepare('SELECT id, title FROM courses WHERE id = ?');
$stmt->execute([$id]);
$course = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$course) {
    header('Location: dashboard.php');
    exit;
}

$page_title = 'Delete Course';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="container form-page">
    <h2>Delete Course</h2>
    <p>Are you sure you want to delete <strong><?php echo e($course['title']); ?></strong>?</p>
    <form method="post" action="delete_course.php?id=<?php echo (int) $id; ?>">
        <input type="hidden" name="confirm" value="1">
        <button type="submit" class="btn btn-danger">Yes, Delete</button>
        <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

require_login();

// Only students can enroll
if (is_admin()) {
    header('Location: dashboard.php?error=admin_cannot_enroll');
    exit;
}

$course_id = isset($_GET['course_id']) ? (int) $_GET['course_id'] : (isset($_POST['course_id']) ? (int) $_POST['course_id'] : 0);
if ($course_id <= 0) {
    header('Location: dashboard.php?error=invalid_course');
    exit;
}

// Check course exists
$stmt = $pdo->prepare('SELECT id FROM courses WHERE id = ?');
$stmt->execute([$course_id]);
if (!$stmt->fetch()) {
    header('Location: dashboard.php?error=invalid_course');
    exit;
}

$user_id = (int) $_SESSION['user_id'];

// Check not already enrolled
$stmt = $pdo->prepare('SELECT id FROM enrollments WHERE user_id = ? AND course_id = ?');
$stmt->execute([$user_id, $course_id]);
if ($stmt->fetch()) {
    header('Location: dashboard.php?error=already_enrolled');
    exit;
}

// Insert enrollment
$stmt = $pdo->prepare('INSERT INTO enrollments (user_id, course_id) VALUES (?, ?)');
$stmt->execute([$user_id, $course_id]);

header('Location: dashboard.php?enrolled=1&course_id=' . $course_id);
exit;

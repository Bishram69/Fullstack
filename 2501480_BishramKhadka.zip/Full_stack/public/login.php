<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

// If already logged in, redirect to dashboard
if (!empty($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

// Handle form submission (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Get and trim input
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    // Basic validation
    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password.';
    } else {
        // Find user by username using prepared statement (prevents SQL injection)
        $stmt = $pdo->prepare('SELECT id, username, password, role FROM users WHERE username = ?');
        $stmt->execute([$username]);

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Check if user exists and password matches (secure comparison)
        if ($user && password_verify($password, $user['password'])) {
            // Regenerate session ID to prevent session fixation
            session_regenerate_id(true);

            // Store user info in session
            $_SESSION['user_id']   = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role']     = $user['role'];

            // Redirect to dashboard
            header('Location: dashboard.php');
            exit;
        } else {
            // Don't reveal whether username or password was wrong (security)
            $error = 'Invalid username or password.';
        }
    }
}

$page_title = 'Login';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="container form-page">
    <h2>Login</h2>

    <?php if (isset($_GET['registered']) && $_GET['registered'] === '1'): ?>
        <div class="alert alert-success">Registration successful. You can now log in.</div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-error"><?php echo e($error); ?></div>
    <?php endif; ?>

    <form method="post" action="login.php" class="form-box">
        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required
                   value="<?php echo e($_POST['username'] ?? ''); ?>"
                   autocomplete="username">
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required
                   autocomplete="current-password">
        </div>
        <button type="submit" class="btn btn-primary">Login</button>
    </form>

    <p class="form-footer">Don't have an account? <a href="register.php">Register</a>.</p>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

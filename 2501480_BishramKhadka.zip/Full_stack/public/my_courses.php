<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

require_login();

$page_title = 'My Courses';

$user_id = (int) $_SESSION['user_id'];
$stmt = $pdo->prepare('
    SELECT c.id, c.title, c.description, c.category, c.price, c.created_at, e.enrolled_at,
           u.username AS instructor_username
    FROM enrollments e
    JOIN courses c ON c.id = e.course_id
    LEFT JOIN users u ON c.instructor_id = u.id
    WHERE e.user_id = ?
    ORDER BY e.enrolled_at DESC
');
$stmt->execute([$user_id]);
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container">
    <div class="page-header">
        <h2>My Enrolled Courses</h2>
        <a href="dashboard.php" class="btn btn-secondary">Back to All Courses</a>
    </div>

    <?php if (empty($courses)): ?>
        <p class="no-data">You are not enrolled in any courses yet. <a href="dashboard.php">Browse courses</a> to enroll.</p>
    <?php else: ?>
        <table class="course-table">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Category</th>
                    <th>Instructor</th>
                    <th>Price</th>
                    <th>Enrolled</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($courses as $course): ?>
                    <tr>
                        <td><?php echo e($course['title']); ?></td>
                        <td><?php echo e($course['category']); ?></td>
                        <td><?php echo !empty($course['instructor_username']) ? e($course['instructor_username']) : '—'; ?></td>
                        <td>NPR <?php echo e(number_format($course['price'], 2)); ?></td>
                        <td><?php echo e(date('Y-m-d', strtotime($course['enrolled_at']))); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

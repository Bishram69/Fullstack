<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Only allow logged-in users to search (optional - remove if you want public search)
require_login();

// Get search query from GET parameter (e.g. ?q=php)
$q = trim($_GET['q'] ?? '');

// Set JSON header so browser treats response as JSON
header('Content-Type: application/json; charset=utf-8');

// If empty search, return empty array
if ($q === '') {
    echo json_encode([]);
    exit;
}

// Search by title OR category OR instructor username 
$pattern = '%' . $q . '%';
$stmt = $pdo->prepare('
    SELECT c.id, c.title, c.description, c.category, c.price, c.created_at, u.username AS instructor_username
    FROM courses c
    LEFT JOIN users u ON c.instructor_id = u.id
    WHERE c.title LIKE ? OR c.category LIKE ? OR u.username LIKE ?
    ORDER BY c.title
');
$stmt->execute([$pattern, $pattern, $pattern]);
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Add enrolled flag for current user 
$enrolled_course_ids = [];
if (!empty($_SESSION['user_id'])) {
    $stmt = $pdo->prepare('SELECT course_id FROM enrollments WHERE user_id = ?');
    $stmt->execute([(int) $_SESSION['user_id']]);
    $enrolled_course_ids = array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'course_id');
}
foreach ($courses as &$course) {
    $course['enrolled'] = in_array((int) $course['id'], $enrolled_course_ids, true);
}
unset($course);

// Output JSON
echo json_encode($courses);
